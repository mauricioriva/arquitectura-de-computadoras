En estos ejemplos se tratan los temas:

   * Proceso de compilación.
   * Comandos de gcc para compilar archivos de código fuente.
   * Cabeceras.
   * Directiva include.

Lee primero el archivo ej_01_main.c.

Ejercicios:

1. Compila el archivo de código fuente ej_01_main.c.
2. Compila nuevamente el archivo pero cambia el nombre del archivo ejecutable de salida.
2. Compila el archivo de código fuento ej_01.c a un archivo de código objeto.
3. Compila los archivos ej_01_main.c y ej_01.c juntos.
