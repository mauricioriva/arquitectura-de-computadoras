/*
  
  El arhivo ej_01.c no contiene una declaracion de funcion main, por lo que se debe compilar como:
  
  gcc -c ej_01.c

  Produciendo el archivo de código objeto ej_01.o
  
*/

